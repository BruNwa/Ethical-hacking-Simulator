package az.brunwa.com.ehs

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()

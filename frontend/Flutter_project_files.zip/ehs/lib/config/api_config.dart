class ApiConfig {
  //Make sure that your backend's link is supported with an SSL certificate (HTTPS)
  // Or your frontend is running in the same HTTP protocol as your backend in order for the communication to take place
  static const String baseUrl = 'https://Your-Backend-Ip';

  // Define endpoints with explicit HTTP
  static String get scenariosEndpoint => '$baseUrl/api/scenarios';
  static String get startScenarioEndpoint => '$baseUrl/api/start-scenario';
  static String get executeCommandEndpoint => '$baseUrl/api/execute-command';
  static String get refreshSessionEndpoint => '$baseUrl/api/refresh-session';
  static String get sendBaitEmailEndpoint => '$baseUrl/api/send-bait-email';
}


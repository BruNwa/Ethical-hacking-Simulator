import 'dart:collection';
import 'package:ehs/config/api_config.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:google_fonts/google_fonts.dart';
import 'package:animated_text_kit/animated_text_kit.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:rive/rive.dart' as rive;
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import 'dart:html' as html;
import 'dart:convert';
import 'dart:async';
import 'error_page.dart';

class GradientTextButton extends StatefulWidget {
  const GradientTextButton({Key? key}) : super(key: key);

  @override
  _GradientTextButtonState createState() => _GradientTextButtonState();
}

class _GradientTextButtonState extends State<GradientTextButton>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  Future<void> _launchURL() async {
    final Uri url = Uri.parse('https://www.linkedin.com/in/anwar-zaim'); // Replace with your URL
    if (!await launchUrl(url)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(seconds: 2),
      vsync: this,
    )..repeat();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _launchURL,
      child: MouseRegion(
        cursor: SystemMouseCursors.click,
        child: AnimatedBuilder(
          animation: _controller,
          builder: (context, child) {
            return ShaderMask(
              shaderCallback: (bounds) {
                return LinearGradient(
                  colors: [
                    Color(0xFF00FF9C),  // Your green accent color
                    Colors.white,
                    Color(0xFF00FF9C),  // Your green accent color
                  ],
                  stops: [0.0, 0.5, 1.0],
                  begin: Alignment(-1.0 + (2 * _controller.value), 0.0),
                  end: Alignment(0.0 + (2 * _controller.value), 0.0),
                ).createShader(bounds);
              },
              child: Text(
                "Anwar Zaim",
                style: TextStyle(
                  fontSize: 16,
                  color: Colors.white,  // This becomes the mask color
                ),
              ),
            );
          },
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
class RiveBackground extends StatefulWidget {
  const RiveBackground({Key? key}) : super(key: key);

  @override
  _RiveBackgroundState createState() => _RiveBackgroundState();
}

class _RiveBackgroundState extends State<RiveBackground> {
  rive.StateMachineController? _controller;

  void _onRiveInit(rive.Artboard artboard) {
    _controller = rive.StateMachineController.fromArtboard(
      artboard,
      'State Machine 1',
    );
    if (_controller != null) {
      artboard.addController(_controller!);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Positioned.fill(
      child: rive.RiveAnimation.asset(
        'assets/rive/background.riv',
        fit: BoxFit.cover,
        onInit: _onRiveInit,
      ),
    );
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }
}

class SessionManager {
  static final SessionManager _instance = SessionManager._internal();
  factory SessionManager() => _instance;
  SessionManager._internal();

  Timer? _refreshTimer;
  String? _containerId;
  bool _isActive = false;

  void startSessionRefresh(String containerId) {
    _containerId = containerId;
    _isActive = true;
    _refreshTimer?.cancel();
    _refreshSession();
    _refreshTimer = Timer.periodic(Duration(minutes: 4), (timer) {
      if (_isActive) {
        _refreshSession();
      } else {
        timer.cancel();
      }
    });
  }

  Future<void> _refreshSession() async {
    if (_containerId == null || !_isActive) return;

    try {
      final response = await http.post(
        Uri.parse(ApiConfig.refreshSessionEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'container_id': _containerId,
        }),
      );

      if (response.statusCode != 200) {
        print('Session refresh failed: ${response.body}');
        stopSessionRefresh();
      }
    } catch (e) {
      print('Session refresh error: $e');
      stopSessionRefresh();
    }
  }

  void stopSessionRefresh() {
    _isActive = false;
    _refreshTimer?.cancel();
    _refreshTimer = null;
    _containerId = null;
  }

  bool get isActive => _isActive;
}


void main() {
  runApp(HackingSimulator());
}
class ThemeConfig {
  static const mainGradient = [Color(0xFF1E1E2E), Color(0xFF2D2D44)];
  static const accentColor = Color(0xFF00FF9C);
  static const secondaryAccent = Color(0xFFFF004D);
}
class HackingSimulator extends StatelessWidget {


  Future<bool> _checkBackendConnectivity() async {
    try {
      final response = await http.get(
        Uri.parse(ApiConfig.scenariosEndpoint),
      ).timeout(Duration(seconds: 5));
      return response.statusCode == 200;
    } catch (e) {
      print('Backend connectivity check failed: $e');
      return false;
    }
  }


  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Ethical Hacking Simulator',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: ThemeConfig.mainGradient[0],
        textTheme: GoogleFonts.jetBrainsMonoTextTheme(
          Theme.of(context).textTheme.apply(
            bodyColor: ThemeConfig.accentColor,
            displayColor: ThemeConfig.accentColor,
          ),
        ),
      ),
      home: FutureBuilder<bool>(
        future: _checkBackendConnectivity(),
        builder: (context, snapshot) {
          print('Connection state: ${snapshot.connectionState}');

          if (snapshot.hasError) {
            print('Error: ${snapshot.error}');
            return ErrorPage();
          }

          if (snapshot.connectionState == ConnectionState.waiting) {
            return LandingPage();
          }

          if (snapshot.hasData && snapshot.data == true) {
            return LandingPage();
          }

          return LandingPage();
        },
      ),
    );
  }
}

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  rive.StateMachineController? _controller;
  rive.SMITrigger? _introTrigger;
  rive.SMITrigger? _bingClickTrigger;
  bool _showGetStarted = false;
  bool _isFirstClickDone = false;

  @override
  void initState() {
    super.initState();
    // Add this to ensure proper viewport meta tags
    if (kIsWeb) {
      html.document.documentElement?.setAttribute('style', 'height: 100vh; overflow: hidden;');
    }
  }

  void _onRiveInit(rive.Artboard artboard) {
    _controller = rive.StateMachineController.fromArtboard(
      artboard,
      'State Machine 1',
    );

    if (_controller != null) {
      artboard.addController(_controller!);
      _introTrigger = _controller!.findInput<bool>('bing_intro') as rive.SMITrigger;
      _bingClickTrigger = _controller!.findInput<bool>('bing_click') as rive.SMITrigger;
    }
  }

  void _handleRiveButtonPress() async {
    if (!_isFirstClickDone) {
      // First click
      _introTrigger?.fire();
      setState(() {
        _showGetStarted = true;
        _isFirstClickDone = true;
      });
    } else {
      // Second click
      _bingClickTrigger?.fire();
      await Future.delayed(Duration(milliseconds: 800));

      // Check backend connectivity before navigating
      try {
        final response = await http.get(
          Uri.parse(ApiConfig.scenariosEndpoint),
        ).timeout(Duration(seconds: 5));

        if (response.statusCode == 200) {
          Navigator.of(context).pushReplacement(
            PageRouteBuilder(
              pageBuilder: (context, animation, secondaryAnimation) => HomePage(),
              transitionsBuilder: (context, animation, secondaryAnimation, child) {
                return FadeTransition(opacity: animation, child: child);
              },
              transitionDuration: Duration(milliseconds: 800),
            ),
          );
        } else {
          Navigator.of(context).pushReplacement(
            PageRouteBuilder(
              pageBuilder: (context, animation, secondaryAnimation) => ErrorPage(),
              transitionsBuilder: (context, animation, secondaryAnimation, child) {
                return FadeTransition(opacity: animation, child: child);
              },
              transitionDuration: Duration(milliseconds: 800),
            ),
          );
        }
      } catch (e) {
        Navigator.of(context).pushReplacement(
          PageRouteBuilder(
            pageBuilder: (context, animation, secondaryAnimation) => ErrorPage(),
            transitionsBuilder: (context, animation, secondaryAnimation, child) {
              return FadeTransition(opacity: animation, child: child);
            },
            transitionDuration: Duration(milliseconds: 800),
          ),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    // Get viewport dimensions
    final viewportHeight = MediaQuery.of(context).size.height;
    final viewportWidth = MediaQuery.of(context).size.width;

    return Scaffold(
      body: LayoutBuilder(
        builder: (context, constraints) {
          // Calculate responsive sizes based on viewport
          final isSmallScreen = constraints.maxWidth < 600;
          final contentWidth = isSmallScreen ? constraints.maxWidth * 0.9 : 600.0;
          final fontSize = isSmallScreen ? constraints.maxWidth * 0.06 : 32.0;

          return Container(
            width: constraints.maxWidth,
            height: constraints.maxHeight,
            child: SingleChildScrollView(
              child: Container(
                constraints: BoxConstraints(
                  minHeight: viewportHeight,
                ),
                child: Stack(
                  children: [
                    const RiveBackground(),

                    Center(
                      child: Container(
                        width: contentWidth,
                        padding: EdgeInsets.symmetric(
                          horizontal: 20,
                          vertical: isSmallScreen ? 40 : 60,
                        ),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Image.asset(
                              "assets/logo/logo.png",
                              width: isSmallScreen ? viewportWidth * 0.2 : 80,
                              height: isSmallScreen ? viewportWidth * 0.2 : 80,
                              fit: BoxFit.contain,
                            ),
                            Text(
                              'ETHICAL HACKING\nSIMULATOR',
                              textAlign: TextAlign.center,
                              style: GoogleFonts.jetBrainsMono(
                                fontSize: fontSize,
                                fontWeight: FontWeight.bold,
                                color: Colors.white,
                                height: 1.5,
                              ),
                            ).animate()
                                .fadeIn(duration: 800.ms)
                                .scale(delay: 400.ms),
                            SizedBox(height: isSmallScreen ? 20 : 40),

                            ShaderMask(
                              shaderCallback: (Rect bounds) {
                                return LinearGradient(
                                  colors: [
                                    Color(0xFF00FF9C),
                                    Color(0xFFFF004D),
                                  ],
                                ).createShader(bounds);
                              },
                              child: Text(
                                'Learn. Hack. Protect.',
                                style: GoogleFonts.jetBrainsMono(
                                  fontSize: isSmallScreen ? fontSize * 0.5 : 18,
                                  color: Colors.white,
                                ),
                              ),
                            ),

                            SizedBox(height: isSmallScreen ? 10 : 20),

                            Container(
                              width: isSmallScreen ? viewportWidth * 0.8 : 500,
                              height: isSmallScreen ? viewportHeight * 0.3 : 400,
                              child: MouseRegion(
                                cursor: SystemMouseCursors.click,
                                child: GestureDetector(
                                  onTap: _handleRiveButtonPress,
                                  child: rive.RiveAnimation.asset(
                                    'assets/rive/button.riv',
                                    fit: BoxFit.contain,
                                    onInit: _onRiveInit,
                                  ),
                                ),
                              ),
                            ),

                            if (_showGetStarted)
                              Container(
                                width: isSmallScreen ? viewportWidth * 0.8 : 300,
                                margin: EdgeInsets.only(top: 20),
                                child: Container(
                                  padding: EdgeInsets.symmetric(
                                    horizontal: 16,
                                    vertical: 12,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(12),
                                    border: Border.all(
                                      color: Color(0xFF00FF9C).withOpacity(0.3),
                                    ),
                                  ),
                                  child: Column(
                                    mainAxisSize: MainAxisSize.min,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.warning_amber_rounded,
                                            color: Color(0xFFEAF120),
                                            size: isSmallScreen ? 15 : 18,
                                          ),
                                          SizedBox(width: 8),
                                          Text(
                                            'DISCLAIMER',
                                            style: GoogleFonts.jetBrainsMono(
                                              fontSize: isSmallScreen ? 12 : 14,
                                              fontWeight: FontWeight.bold,
                                              color: Color(0xFFEAF120),
                                            ),
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 4),
                                      Text(
                                        'Educational purposes only.',
                                        style: GoogleFonts.jetBrainsMono(
                                          fontSize: isSmallScreen ? 10 : 12,
                                          color: Colors.white.withOpacity(0.9),
                                        ),
                                      ),
                                    ],
                                  ),
                                ).animate()
                                    .fadeIn(duration: 400.ms)
                                    .slideY(begin: 0.3, end: 0),
                              ),

                            Container(
                              padding: EdgeInsets.only(top: 20),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  MouseRegion(
                                    cursor: SystemMouseCursors.click,
                                    child: GestureDetector(
                                      onTap: () {
                                        launchUrl(Uri.parse('https://github.com/BruNwa'));
                                      },
                                      child: Container(
                                        padding: EdgeInsets.all(12),
                                        child: FaIcon(
                                          FontAwesomeIcons.github,
                                          color: Colors.white,
                                          size: isSmallScreen ? 20 : 24,
                                        ),
                                      ),
                                    ).animate()
                                        .fadeIn(duration: 400.ms)
                                        .slideY(begin: 0.3, end: 0),
                                  ),
                                  Text(
                                    "Made with love ❤️ and creativity.",
                                    style: TextStyle(
                                      color: Colors.white,
                                      fontSize: isSmallScreen ? 12 : 14,
                                    ),
                                  ),
                                  GradientTextButton()
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    if (kIsWeb) {
      html.document.documentElement?.removeAttribute('style');
    }
    _controller?.dispose();
    super.dispose();
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  List<String> loadingTexts = [
    'Initializing system...',
    'Loading security modules...',
    'Configuring environment...',
    'Starting simulation...',
  ];
  int currentTextIndex = 0;

  @override
  void initState() {
    super.initState();
    Timer.periodic(Duration(seconds: 1), (timer) {
      if (mounted) {
        setState(() {
          if (currentTextIndex < loadingTexts.length - 1) {
            currentTextIndex++;
          } else {
            timer.cancel();
            Future.delayed(Duration(milliseconds: 500), () {
              Navigator.of(context).pushReplacement(
                MaterialPageRoute(builder: (context) => HomePage()),
              );
            });
          }
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.mainGradient[0],
      body: Center(
        child: GlassmorphicContainer(
          width: MediaQuery.of(context).size.width * 0.8,
          height: 200,
          borderRadius: 20,
          blur: 20,
          border: 2,
          linearGradient: LinearGradient(
            colors: [
              Colors.white.withOpacity(0.1),
              Colors.white.withOpacity(0.05),
            ],
          ),
          borderGradient: LinearGradient(
            colors: [ThemeConfig.accentColor.withOpacity(0.2), ThemeConfig.accentColor.withOpacity(0.1)],
          ),
          child: Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                AnimatedTextKit(
                  animatedTexts: [
                    TypewriterAnimatedText(
                      loadingTexts[currentTextIndex],
                      textStyle: GoogleFonts.jetBrainsMono(
                        fontSize: 20,
                        color: ThemeConfig.accentColor,
                      ),
                      speed: Duration(milliseconds: 50),
                    ),
                  ],
                  totalRepeatCount: 1,
                  displayFullTextOnTap: true,
                ),
                SizedBox(height: 40),
                LoadingDots(),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class LoadingDots extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: List.generate(
        3,
            (index) => Container(
          margin: EdgeInsets.symmetric(horizontal: 4),
          child: CircleAvatar(
            radius: 4,
            backgroundColor: ThemeConfig.accentColor,
          ).animate(
            onPlay: (controller) => controller.repeat(),
          ).scaleXY(
            begin: 0.5,
            end: 1.0,
            duration: 600.ms,
            delay: Duration(milliseconds: index * 200),
            curve: Curves.easeInOut,
          ),
        ),
      ),
    );
  }
}

class ScenarioCard extends StatelessWidget {
  final String title;
  final String description;
  final List<String> tools;
  final String difficulty;
  final VoidCallback onTap;

  ScenarioCard({
    required this.title,
    required this.description,
    required this.tools,
    required this.difficulty,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GlassmorphicContainer(
      width: double.infinity,
      height: double.infinity,
      borderRadius: 15,
      blur: 20,
      border: 2,
      linearGradient: LinearGradient(
        colors: [
          Colors.white.withOpacity(0.1),
          Colors.white.withOpacity(0.05),
        ],
      ),
      borderGradient: LinearGradient(
        colors: [
          ThemeConfig.accentColor.withOpacity(0.2),
          ThemeConfig.accentColor.withOpacity(0.1),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(15),
          child: Container(
            padding: EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: 8),
                Text(
                  description,
                  style: GoogleFonts.jetBrainsMono(
                    fontSize: 14,
                    color: Colors.white70,
                  ),
                ),
                Spacer(),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: _getDifficultyColor(difficulty),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    difficulty,
                    style: GoogleFonts.jetBrainsMono(
                      fontSize: 12,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    ).animate()
        .fadeIn(duration: 400.ms)
        .scale(delay: 200.ms);
  }

  Color _getDifficultyColor(String difficulty) {
    switch (difficulty.toLowerCase()) {
      case 'beginner':
        return Colors.green.withOpacity(0.7);
      case 'intermediate':
        return Colors.orange.withOpacity(0.7);
      case 'advanced':
        return Colors.red.withOpacity(0.7);
      default:
        return Colors.blue.withOpacity(0.7);
    }
  }
}

class CommandPalette extends StatelessWidget {
  final Map<String, String> commands;
  final List<String> commandsOrder;
  final String targetIp;
  final Function(String) onCommandSelected;
  final bool isSmallScreen;

  const CommandPalette({
    Key? key,
    required this.commands,
    required this.commandsOrder,
    required this.targetIp,
    required this.onCommandSelected,
    required this.isSmallScreen,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return PopupMenuButton<String>(
      child: GlassmorphicContainer(
        width: double.infinity,
        height: isSmallScreen ? 45 : 50,
        borderRadius: 12,
        blur: 20,
        border: 2,
        linearGradient: LinearGradient(
          colors: [
            Colors.green.withOpacity(0.2),
            Colors.green.withOpacity(0.1),
          ],
        ),
        borderGradient: LinearGradient(
          colors: [
            Colors.green.withOpacity(0.2),
            Colors.green.withOpacity(0.1),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.terminal,
                  color: Colors.white,
                  size: isSmallScreen ? 16 : 20,
                ),
                SizedBox(width: 8),
                Text(
                  'Commands',
                  style: GoogleFonts.jetBrainsMono(
                    color: Colors.white,
                    fontSize: isSmallScreen ? 12 : 14,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
      itemBuilder: (context) {
        // Use the order from the backend
        return commandsOrder.map((commandName) {
          String command = commands[commandName] ?? '';
          String formattedCommand = command.replaceAll('TARGET_IP', targetIp);
          return PopupMenuItem<String>(
            value: formattedCommand,
            child: Text(
              commandName,
              style: GoogleFonts.jetBrainsMono(
                fontSize: isSmallScreen ? 12 : 14,
              ),
            ),
          );
        }).toList();
      },
      onSelected: onCommandSelected,
    );
  }
}


class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  LinkedHashMap<String, dynamic> scenarios = LinkedHashMap();
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(seconds: 2),
      vsync: this,
    )..repeat();
    _loadScenarios();
  }

  Future<void> _loadScenarios() async {
    try {
      final response = await http.get(
        Uri.parse(ApiConfig.scenariosEndpoint),
      ).timeout(const Duration(seconds: 30));

      if (response.statusCode == 200) {
        if (mounted) {
          final Map<String, dynamic> data = json.decode(response.body);
          setState(() {
            scenarios = LinkedHashMap.from(data);
            isLoading = false;
          });
        }
      } else {
        throw Exception('Failed to load scenarios: ${response.statusCode}');
      }
    } catch (e) {
      print('Error loading scenarios: $e');
      if (mounted) {
        setState(() => isLoading = false);
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => ErrorPage()),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          const RiveBackground(),
          if (isLoading)
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  AnimatedTextKit(
                    animatedTexts: [
                      TypewriterAnimatedText(
                        'Initializing System...',
                        textStyle: GoogleFonts.jetBrainsMono(
                          fontSize: 18,
                          color: Colors.green[300],
                        ),
                        speed: Duration(milliseconds: 100),
                      ),
                    ],
                    repeatForever: true,
                  ),
                  SizedBox(height: 20),
                  LoadingDots(),
                ],
              ),
            )
          else
            CustomScrollView(
              slivers: [
                SliverAppBar(
                  expandedHeight: 250,
                  floating: false,
                  pinned: true,
                  backgroundColor: Colors.transparent,
                  flexibleSpace: LayoutBuilder(
                    builder: (BuildContext context, BoxConstraints constraints) {
                      final top = constraints.biggest.height;
                      final collapsedHeight = MediaQuery.of(context).padding.top + kToolbarHeight;
                      final expandedHeight = 250;
                      final percent = (top - collapsedHeight) / (expandedHeight - collapsedHeight);

                      return FlexibleSpaceBar(
                        centerTitle: true,
                        title: Container(
                          padding: EdgeInsets.symmetric(
                            horizontal: 16,
                            vertical: 8,
                          ),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: Colors.green.withOpacity(0.3 * percent.clamp(0, 1)),
                              width: 2,
                            ),
                            borderRadius: BorderRadius.circular(30),
                          ),
                          child: Text(
                            'ETHICAL HACKING SIMULATOR',
                            style: GoogleFonts.jetBrainsMono(
                              color: Colors.green[300],
                              fontSize: 12 + (2 * percent.clamp(0, 1)),
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ).animate()
                            .fadeIn(duration: 600.ms),
                        background: Stack(
                          children: [
                            Center(
                              child: Icon(
                                Icons.security,
                                size: 60,
                                color: Colors.green[300],
                              ).animate()
                                  .fade(duration: 600.ms)
                                  .scale(delay: 200.ms),
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                ),
                SliverToBoxAdapter(
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(24, 32, 24, 16),
                    child: Container(
                      padding: EdgeInsets.symmetric(vertical: 16),
                      child: Row(
                        children: [
                          Container(
                            width: 4,
                            height: 24,
                            decoration: BoxDecoration(
                              color: Colors.green[300],
                              borderRadius: BorderRadius.circular(2),
                            ),
                          ),
                          SizedBox(width: 12),
                          Text(
                            'Available Scenarios',
                            style: GoogleFonts.jetBrainsMono(
                              color: Colors.green[300],
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                SliverPadding(
                  padding: EdgeInsets.fromLTRB(24, 16, 24, 24),
                  sliver: SliverGrid(
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: MediaQuery.of(context).size.width > 1200 ? 3 :
                      MediaQuery.of(context).size.width > 800 ? 2 : 1,
                      mainAxisSpacing: 20,
                      crossAxisSpacing: 20,
                      childAspectRatio: 1.1,
                    ),
                    delegate: SliverChildBuilderDelegate(
                          (context, index) {
                        String key = scenarios.keys.elementAt(index);
                        var scenario = scenarios[key];
                        return ScenarioCard(
                          title: scenario['name'],
                          description: scenario['description'],
                          tools: List<String>.from(scenario['tools']),
                          difficulty: scenario['difficulty'],
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => TerminalPage(
                                scenarioType: key,
                                scenario: scenario,
                              ),
                            ),
                          ),
                        ).animate()
                            .fadeIn(
                          duration: 600.ms,
                          delay: Duration(milliseconds: index * 100),
                        )
                            .slideY(
                          begin: 0.2,
                          end: 0,
                          curve: Curves.easeOut,
                          duration: 600.ms,
                          delay: Duration(milliseconds: index * 100),
                        );
                      },
                      childCount: scenarios.length,
                    ),
                  ),
                ),
              ],
            ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}



class CommandHelper extends StatelessWidget {
  final Map<String, dynamic> scenario;

  const CommandHelper({
    Key? key,
    required this.scenario,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green[700]!),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'Available Tools:',
            style: TextStyle(
              color: Colors.green[300],
              fontWeight: FontWeight.bold,
              fontSize: 16,
            ),
          ),
          SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: (scenario['tools'] as List<String>).map((tool) {
              return Container(
                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.green[900],
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Text(
                  tool,
                  style: GoogleFonts.firaCode(
                    color: Colors.green[300],
                    fontSize: 12,
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }
}
class TerminalPage extends StatefulWidget {
  final String scenarioType;
  final Map<String, dynamic> scenario;

  TerminalPage({
    required this.scenarioType,
    required this.scenario,
  });

  @override
  _TerminalPageState createState() => _TerminalPageState();
}

class _TerminalPageState extends State<TerminalPage> {
  final TextEditingController _commandController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final SessionManager _sessionManager = SessionManager();
  List<String> _output = [];
  String? _containerId;
  String? _targetIp;
  bool _isInitializing = true;

  @override
  void initState() {
    super.initState();
    _initializeScenario();
  }

  Future<void> _initializeScenario() async {
    try {
      final response = await http.post(
        Uri.parse(ApiConfig.startScenarioEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({'type': widget.scenarioType}),
      ).timeout(const Duration(seconds: 60));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['container_id'] != null && data['target_ip'] != null) {
          if (mounted) {
            setState(() {
              _containerId = data['container_id'];
              _targetIp = data['target_ip'];
              _isInitializing = false;
              _output.add('''
░█████╗░███████╗  ███████╗██╗░░██╗░██████╗
██╔══██╗╚════██║  ██╔════╝██║░░██║██╔════╝
███████║░░███╔═╝  █████╗░░███████║╚█████╗░
██╔══██║██╔══╝░░  ██╔══╝░░██╔══██║░╚═══██╗
██║░░██║███████╗  ███████╗██║░░██║██████╔╝
╚═╝░░╚═╝╚══════╝  ╚══════╝╚═╝░░╚═╝╚═════╝░                                      
''');
              _output.add('Scenario initialized successfully!');
              _output.add('Container ID: ${_containerId}');
              _output.add('Target IP: ${_targetIp}');
              _output.add('\nEnter your commands or use the command palette below:');
            });
          }
          _sessionManager.startSessionRefresh(_containerId!);
          _scrollToBottom();
        } else {
          throw Exception('Invalid response data');
        }
      } else {
        throw Exception('Failed to initialize scenario');
      }
    } catch (e) {
      print('Error initializing scenario: $e');
      if (mounted) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => ErrorPage()),
        );
      }
    }
  }

  void _scrollToBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  Future<void> _executeCommand(String command) async {
    if (command.isEmpty) return;

    setState(() {
      _output.add('\n\$ $command');
    });
    _scrollToBottom();

    try {
      if (_containerId == null) {
        throw Exception('No active container - please reinitialize the scenario');
      }

      final response = await http.post(
        Uri.parse(ApiConfig.executeCommandEndpoint),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'command': command,
          'container_id': _containerId,
        }),
      ).timeout(const Duration(seconds: 10));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (mounted) {
          setState(() {
            if (data['output'] != null) {
              if (data['output'] is String) {
                _output.addAll(data['output'].split('\n'));
              } else if (data['output'] is List) {
                _output.addAll(List<String>.from(data['output']));
              }
            }

            if (data['error'] != null) {
              _output.add('Error: ${data['error']}');
            }
          });
        }
      } else {
        throw Exception('Command execution failed');
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _output.add('Error executing command: $e');
        });
      }
      if (e is TimeoutException) {
        Navigator.of(context).pushReplacement(
          MaterialPageRoute(builder: (context) => ErrorPage()),
        );
      }
    }

    _commandController.clear();
    _scrollToBottom();
  }

  Future<void> _sendBaitEmail() async {
    if (_emailController.text.isEmpty) {
      setState(() {
        _output.add('Error: Email address is required');
      });
      return;
    }

    try {

      if (mounted) {
        setState(() {
          _output.add('Email sent successfully to ${_emailController.text}');
        });
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _output.add('Error sending email: $e');
        });
        if (e is TimeoutException) {
          Navigator.of(context).pushReplacement(
            MaterialPageRoute(builder: (context) => ErrorPage()),
          );
        }
      }
    }

    _emailController.clear();
    _scrollToBottom();
  }

  void _handleCommandSelection(String command) {
    _commandController.text = command;
    _executeCommand(command);
  }
  @override
  Widget build(BuildContext context) {
    (widget.scenario['commands'] as Map<String, dynamic>).cast<String, String>();

    final screenSize = MediaQuery.of(context).size;
    final isSmallScreen = screenSize.width < 600;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.scenario['name'],
          style: TextStyle(fontSize: isSmallScreen ? 18 : 24),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          // Terminal Output
          Expanded(
            flex: 2,
            child: Container(
              margin: EdgeInsets.all(isSmallScreen ? 8 : 16),
              decoration: BoxDecoration(
                color: Colors.white10.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(
                  image: AssetImage('assets/logo/logo.png'),
                  fit: BoxFit.contain,
                  opacity: 0.5,
                ),
              ),
              child: _isInitializing
                  ? Center(
                child: AnimatedTextKit(
                  animatedTexts: [
                    TypewriterAnimatedText(
                      'Initializing Environment...',
                      speed: Duration(milliseconds: 100),
                    ),
                  ],
                  repeatForever: true,
                ),
              )
                  : SingleChildScrollView(
                controller: _scrollController,
                padding: EdgeInsets.all(isSmallScreen ? 8 : 16),
                child: SelectableText(
                  _output.join('\n'),
                  style: GoogleFonts.firaCode(
                    color: Colors.green[300],
                    fontSize: isSmallScreen ? 12 : 14,
                  ),
                ),
              ),
            ),
          ),

          // Phishing Email Controls (only for phishing scenario)
          if (widget.scenarioType == 'phishing_analysis')
            Container(
              padding: EdgeInsets.all(isSmallScreen ? 8 : 16),
              child: Column(
                children: [
                  TextField(
                    controller: _emailController,
                    style: TextStyle(
                      color: Colors.green[300],
                      fontFamily: 'Fira Code',
                      fontSize: isSmallScreen ? 12 : 14,
                    ),
                    decoration: InputDecoration(
                      hintText: 'Enter target email address...',
                      hintStyle: TextStyle(
                        color: Colors.green[100]?.withOpacity(0.5),
                        fontSize: isSmallScreen ? 12 : 14,
                      ),
                      prefixIcon: Icon(Icons.email, color: Colors.green[300]),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.green[300]!),
                      ),
                      enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.green[300]!),
                      ),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(color: Colors.green[500]!),
                      ),
                    ),
                  ),
                  SizedBox(height: 8),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      Expanded(
                        child: ElevatedButton(
                          onPressed: _sendBaitEmail,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.green[700],
                            padding: EdgeInsets.symmetric(
                              vertical: isSmallScreen ? 12 : 16,
                            ),
                          ),
                          child: Text(
                            'Send Phishing Email',
                            style: TextStyle(
                              fontSize: isSmallScreen ? 12 : 14,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 8),
                      Expanded(
                        child: Container(
                          height: isSmallScreen ? 45 : 50,
                          child: CommandPalette(
                            commands: Map<String, String>.from(widget.scenario['commands'] as Map),
                            commandsOrder: List<String>.from(widget.scenario['commands_order'] as List),
                            targetIp: _targetIp ?? '',
                            onCommandSelected: _handleCommandSelection,
                            isSmallScreen: isSmallScreen,
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

          // Command Palette for non-phishing scenarios
          if (widget.scenarioType != 'phishing_analysis')
            Container(
              padding: EdgeInsets.symmetric(
                horizontal: isSmallScreen ? 8 : 16,
                vertical: 8,
              ),
              child: Row(
                children: [
                  Expanded(
                    child: Container(
                      height: isSmallScreen ? 45 : 50,
                      child: CommandPalette(
                        commands: Map<String, String>.from(widget.scenario['commands'] as Map),
                        commandsOrder: List<String>.from(widget.scenario['commands_order'] as List),
                        targetIp: _targetIp ?? '',
                        onCommandSelected: _handleCommandSelection,
                        isSmallScreen: isSmallScreen,
                      ),
                    ),
                  ),
                ],
              ),
            ),

          // Command Input
          Padding(
            padding: EdgeInsets.all(isSmallScreen ? 8 : 16),
            child: TextField(
              controller: _commandController,
              style: TextStyle(
                color: Colors.green[300],
                fontFamily: 'Fira Code',
                fontSize: isSmallScreen ? 12 : 14,
              ),
              decoration: InputDecoration(
                hintText: 'Enter command...',
                hintStyle: TextStyle(
                  color: Colors.green[100]?.withOpacity(0.5),
                  fontSize: isSmallScreen ? 12 : 14,
                ),
                prefixText: '\$ ',
                prefixStyle: TextStyle(
                  color: Colors.green[300],
                  fontFamily: 'Fira Code',
                  fontSize: isSmallScreen ? 12 : 14,
                ),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.green[300]!),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.green[300]!),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                  borderSide: BorderSide(color: Colors.green[500]!),
                ),
              ),
              onSubmitted: _executeCommand,
            ),
          ),
        ],
      ),
    );
  }



  @override
  void dispose() {
    _commandController.dispose();
    _emailController.dispose();
    _scrollController.dispose();
    _sessionManager.stopSessionRefresh();
    super.dispose();
  }
}


// // Add a loading animation component
// class LoadingDots extends StatefulWidget {
//   @override
//   _LoadingDotsState createState() => _LoadingDotsState();
// }
//
// class _LoadingDotsState extends State<LoadingDots> with TickerProviderStateMixin {
//   late List<AnimationController> _controllers;
//   late List<Animation<double>> _animations;
//   final int numberOfDots = 3;
//
//   @override
//   void initState() {
//     super.initState();
//     _controllers = List.generate(
//       numberOfDots,
//           (index) => AnimationController(
//         duration: Duration(milliseconds: 600),
//         vsync: this,
//       ),
//     );
//
//     _animations = _controllers.map((controller) {
//       return Tween(begin: 0.0, end: 1.0).animate(
//         CurvedAnimation(
//           parent: controller,
//           curve: Curves.easeInOut,
//         ),
//       );
//     }).toList();
//
//     for (var i = 0; i < numberOfDots; i++) {
//       Future.delayed(Duration(milliseconds: i * 200), () {
//         _controllers[i].repeat(reverse: true);
//       });
//     }
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Row(
//       mainAxisAlignment: MainAxisAlignment.center,
//       children: List.generate(
//         numberOfDots,
//             (index) => AnimatedBuilder(
//           animation: _animations[index],
//           builder: (context, child) {
//             return Container(
//               margin: EdgeInsets.symmetric(horizontal: 4),
//               child: Transform.translate(
//                 offset: Offset(0, -4 * _animations[index].value),
//                 child: Container(
//                   width: 8,
//                   height: 8,
//                   decoration: BoxDecoration(
//                     color: Colors.green[300],
//                     shape: BoxShape.circle,
//                   ),
//                 ),
//               ),
//             );
//           },
//         ),
//       ),
//     );
//   }
//
//   @override
//   void dispose() {
//     for (var controller in _controllers) {
//       controller.dispose();
//     }
//     super.dispose();
//   }
// }

// Add helper widgets for the command history
class CommandHistoryOverlay extends StatelessWidget {
  final List<String> history;
  final Function(String) onSelect;

  CommandHistoryOverlay({
    required this.history,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 8),
      padding: EdgeInsets.all(8),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green[300]!),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: history.map((command) => InkWell(
          onTap: () => onSelect(command),
          child: Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(vertical: 4, horizontal: 8),
            child: Text(
              command,
              style: TextStyle(color: Colors.green[300]),
            ),
          ),
        )).toList(),
      ),
    );
  }
}

// Add a custom tooltip widget
class CustomTooltip extends StatelessWidget {
  final String message;

  CustomTooltip({required this.message});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: Colors.black87,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.green[300]!),
      ),
      child: Text(
        message,
        style: TextStyle(color: Colors.green[300]),
      ),
    );
  }
}